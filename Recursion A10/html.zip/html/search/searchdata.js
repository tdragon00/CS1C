var indexSectionsWithContent =
{
  0: "mr",
  1: "m",
  2: "mr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

